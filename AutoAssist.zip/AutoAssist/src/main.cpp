#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>

using namespace geode::prelude;

// Estado global simple
static bool g_userHolding = false; // el dedo del usuario esta en la pantalla
static bool g_botHolding  = false; // lo que el asistente esta "apretando"
static bool g_injecting   = false; // para distinguir input real del inyectado

static bool assistEnabled() {
	return Mod::get()->getSettingValue<bool>("enabled");
}

// ---------------------------------------------------------------------
// AQUI VA LA "IA": decide si en este frame hay que mantener o soltar.
//
// Ahora mismo solo copia al usuario (no hace nada especial).
// Para hacerlo perfecto hay que simular hacia adelante:
//   1. Guardar el estado del jugador (como un checkpoint).
//   2. Simular N frames con "mantener" y N frames con "soltar".
//   3. Quedarte con la opcion que no choca (o la mas segura).
//   4. Restaurar el estado y aplicar esa decision.
// Se aplica a cubo, nave, wave, etc. porque solo decides hold/release.
// ---------------------------------------------------------------------
static bool shouldHold(GJBaseGameLayer* layer) {
	return true; // TODO: reemplazar por la simulacion
}

class $modify(AssistLayer, GJBaseGameLayer) {
	void handleButton(bool down, int button, bool isPlayer1) {
		if (!g_injecting && button == 1 && isPlayer1) {
			// input real del usuario
			g_userHolding = down;
			if (assistEnabled()) {
				// el asistente controla el input; si sueltas, se suelta
				if (!down && g_botHolding) {
					g_injecting = true;
					GJBaseGameLayer::handleButton(false, 1, true);
					g_injecting = false;
					g_botHolding = false;
				}
				return;
			}
		}
		GJBaseGameLayer::handleButton(down, button, isPlayer1);
	}

	void processCommands(float dt) {
		if (assistEnabled() && g_userHolding) {
			bool hold = shouldHold(this);
			if (hold != g_botHolding) {
				g_injecting = true;
				GJBaseGameLayer::handleButton(hold, 1, true);
				g_injecting = false;
				g_botHolding = hold;
			}
		}
		GJBaseGameLayer::processCommands(dt);
	}
};
